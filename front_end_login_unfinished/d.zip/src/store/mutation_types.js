export const CONTACT = {
    GET_CONTACT: 'getContact',
    CREATE_CONTACT: 'createContact',
    DELETE_CONTACT: 'deleteContact',
}

export const DASHBOARD = {
    GET_DASHBOARD: 'getDashboard',
    CREATE_DASHBOARD: 'createDashboard',
    DELETE_DASHBOARD: 'deleteDashboard',
}