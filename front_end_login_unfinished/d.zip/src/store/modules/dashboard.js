import { DASHBOARD } from "../mutation_types"
import axios from 'axios'

const state = {
    record: []
}

const getters = {
}
const actions = {
    getAllDASHBOARD({ commit }) { //commit是调用mutations的
        axios(`http://localhost:8081/task/findAll`)
        .then(res => {
            commit(DASHBOARD.GET_DASHBOARD,res.data);
        })
        .catch((error) => {
            console.log(error)
        })
    },
    
}



const mutations = {
    [DASHBOARD.GET_DASHBOARD](state, dashboard) {
        state.record = dashboard
    },

    [DASHBOARD.CREATE_DASHBOARD](state, dashboard) {
        state.record.push(dashboard)
        axios({
            url: `http://localhost:8081/task/save`,//地址
            method: 'post',
            data: {
                name: dashboard.name,
                contactid: dashboard.contactid,
                time: dashboard['time'].format('YYYY-MM-DD HH:mm:ss'),
                completed: 0,
                description: dashboard.description,
                userId:1,
            }
          })
    },
    
    [DASHBOARD.DELETE_DASHBOARD](state, id) {
        console.log(state);
        for (let i in state.record) {
            //console.log('now on key: ', state.record[i]["id"], 'should delete id ', id)
            if (state.record[i]["taskid"] === id) {
                axios({
                    url: `http://localhost:8081/task/deleteid/${id}`,
                    method: 'delete',
                })
                state.record.splice(i, 1);
            }
        }
    },
}
export default {
    namespaced: true,
    state,
    actions,
    getters,
    mutations
}