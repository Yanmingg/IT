<template>
  <a-descriptions title="Contact Info" bordered>
    <a-descriptions-item label="Name" :span = "1">
      Cloud Database
    </a-descriptions-item>
    <a-descriptions-item label="Organization" :span = "2">
      Prepaid
    </a-descriptions-item>
    <a-descriptions-item label="Moile" :span = "1">
      YES
    </a-descriptions-item>
    <a-descriptions-item label="Email" :span = "2">
      2018-04-24 18:00:00
    </a-descriptions-item>
    <a-descriptions-item label="Tag">
      2019-04-24 18:00:00
    </a-descriptions-item>
    <a-descriptions-item label="Priority" span = "2">
      <a-badge status="processing" text="Running" />
    </a-descriptions-item>
    <a-descriptions-item label="Description">
      Data disk type: MongoDB
      <br />
      Database version: 3.4
      <br />
      Package: dds.mongo.mid
      <br />
      Storage space: 10 GB
      <br />
      Replication factor: 3
      <br />
      Region: East China 1<br />
    </a-descriptions-item>
  </a-descriptions>
</template>
