module.exports = {
    runtimeCompiler: true,
    lintOnSave: false,
    css: {
        loaderOptions: {
            less: {
                javascriptEnabled: true
            }
        }
    }
};